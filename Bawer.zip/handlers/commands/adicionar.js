const Discord = require('discord.js');

exports.run = (client, message, args) => {
  
  let embed = new Discord.MessageEmbed()
  .setColor([255,182,193])
  .setDescription("**Me adicione em seu servidor**")
  .addField("Link:", "[Me adicione](https://discord.com/oauth2/authorize?client_id=805135276208422972&permissions=268565559&scope=bot)")
  .addField("Discord", "Entre no meu Discord de Suporte clicando [Aqui](https://discord.gg/CtbSbn78uF)")
  .addField("Site", "O site ainda estar sendo criado [site](https://sites.google.com/view/bawer-website/inicio)")
  .setFooter(`Comando solicitado por: ${message.author.tag}`)
  .setTimestamp();
  
  message.channel.send(embed)

}