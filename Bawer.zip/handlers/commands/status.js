const Discord = require("discord.js");

exports.run = (client, message, args) => {
    const embed = new Discord.MessageEmbed()
    .setColor('#08ddf5')
    .setDescription(`Brawer infor's ${message.author.username}`)
   .setThumbnail(`https://cdn.discordapp.com/avatars/805135276208422972/f5b4aa992ad6b1f5dc52ba39c670e27e.png?size=1024`)
    .setTimestamp()
    .setFooter(`Comando feito pelo usuario: ${message.author.username} `)
    .addFields(
        {
            name: '<:Bot:825826372143546398> Status <:Bot:825826372143546398>',
            value: `${client.stats}`, 
        }    
    )
    message.channel.send(embed);
}