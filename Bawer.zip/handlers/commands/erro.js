module.exports = {
    name: "restart",
    category: "owner",
    run: async (client, message, args) => {
        if (message.author.id !== '839595775729860659') {
            return message.channel.send(`Você não pode usar este comando!`)
        }
        await message.channel.send(`Ficarei off para reparar o erro`)
        process.exit();
    }
}