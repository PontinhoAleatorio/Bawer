exports.run = (client, message, args) => {
 if (!client.lockit) client.lockit = [];
 if (!message.member.hasPermission("MANAGE_CHANNELS")) return message.reply("❌**Error:** você não tem permissão "); message.channel.createOverwrite(message.guild.id, {
 CREATE_INVITATION: false,
 ATTACH_FILES: null
 })
 message.channel.send(`Prontinho, **${message.author.username}** Agora todos podem mandar arquivos aqui, para bloquear denovo digite .sarquivos`);
 };