exports.run = (client, message, args) => {
 if (!client.lockit) client.lockit = [];
 if (!message.member.hasPermission("MANAGE_CHANNELS")) return message.reply("❌**Error:** você não tem permissão "); message.channel.createOverwrite(message.guild.id, {
 SEND_MESSAGES: false 
 })
 message.channel.send(`lock, **${message.author.username}** eu fechei este canal, digite unlock para desbloqueá-lo`);
 };
 