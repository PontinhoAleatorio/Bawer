exports.run = (client, message, args) => {
 if (!client.lockit) client.lockit = [];
 if (!message.member.hasPermission("MANAGE_CHANNELS")) return message.reply("❌**Error:** você nao tem permissão "); message.channel.createOverwrite(message.guild.id, {
 SEND_MESSAGES: null  //para fazer un comando de unlockchat e so mudar o false para null 
 })
 message.channel.send(`unlock, **${message.author.username}** eu abri este canal, digite lock para bloquear`);
 };
