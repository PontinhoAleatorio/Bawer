const Discord = require('discord.js');

exports.run = (client, message, args) => {
  
  let embed = new Discord.MessageEmbed()
  .setColor([255,182,193])
  .setDescription("**Lives da Twitch recomendadas**")
  .addField("Bl4ckScott:", "[Lives](https://www.twitch.tv/bl4ckscott) quase todos os dias!")
  .addField("RuuKaaZuu", "[Lives](https://www.twitch.tv/rukaazuu)")
  .addField("Duux_", "[Lives](https://www.twitch.tv/duuxmax)")
  .setFooter(`Comando solicitado por: ${message.author.tag}`)
  .setTimestamp();
  
  message.channel.send(embed)

}