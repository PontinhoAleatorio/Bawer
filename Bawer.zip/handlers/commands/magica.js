const Discord = require("discord.js");

exports.run = (client, message, args) => {
    const embed = new Discord.MessageEmbed()
    .setColor('#08ddf5')
    .setDescription(` Oiie ${message.author}`)
    .setTimestamp()
    .setFooter(` Comando feito pelo usuario: ${message.author.username} `)
    .addFields(
      {
        name: '**Meu criador:**',
        value: `Nick atual do criador: Pontinho#3573`,
        inline: true
      },
       {
        name: '**Canal dedicado a mim:**',
        value: `https://www.youtube.com/channel/UCZ3_iD74Ify1HOJX8kdtLsw`,
        inline: true
      },
    )
    message.channel.send(embed);
}
