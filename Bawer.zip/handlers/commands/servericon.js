const discord = require('discord.js')

module.exports = {
    name:"avatar",
    category:"info",
    run: async (client, message, args) => {
        
        const ft = message.guild.iconURL({format:'jpeg', size:1024})
        
        const embed = new discord.MessageEmbed()
        .setDescription(`Quer [baixar o icon?](${ft})`)
        .setImage(ft)
        
        message.channel.send(embed)
        
    }
}