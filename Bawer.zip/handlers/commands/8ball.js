module.exports.run = (Client, Message, Args) => {
  const Respostas = ["Oi", "Bom dia", "Boa noite", "Legal bom dia!", "Prefiro não magoar seus sentimentos", "Com certeza!", "Sim", "Não", "Vai arrumar o que fazer",]

  function randomResposta () {
    return Respostas[Math.floor(Math.random() * Respostas.length)];
  };

  Message.channel.send(randomResposta())
};