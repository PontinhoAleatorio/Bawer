exports.run = async (client, message, args) => {

        message.guild.me.voice.channel.leave();
}