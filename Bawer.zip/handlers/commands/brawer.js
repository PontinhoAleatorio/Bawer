const discord = require("discord.js")
module.exports = {
  name: "8ball",
  aliases: [""],
  description: "",
  run: async (client, message, args) => {
    let answer = ["Estou em testes ainda"] 
    if(!args.slice(0).join(" ")) return message.channel.send("Onde ele está questionando?")
    
    let ranswer = Math.floor((Math.random() * answer.length))
    
    let embed = new discord.MessageEmbed()
    .setColor("RANDOM")
    .setTitle("<:Bawer:842704129230766100> | Braws perguntas")
    .setDescription("8ball")
    .addField("Sua pergunta", args.slice().join(" "))
    .addField("Minha resposta", `${answer[ranswer]}`)
    message.channel.send(embed)
  }
}