const Discord = require('discord.js');

module.exports.run = async (client, message, args) => {
  const sayMessage = args.join(' ');
   if (args.length !== 0) {
    if (message.content.indexOf("@everyone") > -1 || message.content.indexOf("@here") > -1) {
      message.channel.send(" ${message.author} Que audacia? Não vou marcar everyone ou here, caso queira que eu marque basta fazer com o comando: .say")
       } else {
  message.channel.send(sayMessage);
}}}