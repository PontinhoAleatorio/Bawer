const { MessageEmbed } = require("discord.js");
const db = require('quick.db');;

exports.run = async (bot, message, args) => {
        let money = db.all().filter(lb => lb.ID.startsWith(`money${message.guild.id}`)).sort((a, b) => b.data- a.data)
        let moneyBalance = money.slice(0, 10)
        console.log(moneyBalance)
        let content = " ";

        for(let i = 0; i < moneyBalance.length; i++) {
            let user = bot.users.cache.get(moneyBalance[i].ID.split('_')[2])

            content += `${i+1}. ${user} - \$${moneyBalance[i].data} \n`

        }

        const embed = new MessageEmbed()
        .setColor("#000001")
        .setTitle(`${message.guild.name}\' RANK`)
        .setDescription(`** ${content} **`)
        .setTimestamp()

        message.channel.send(embed)
}