const Discord = require('discord.js');

exports.run = (client, message, args) => {
  
  let embed = new Discord.MessageEmbed()
  .setColor([255,182,193])
  .setDescription("**Website**")
  .addField("Site", "Olha meu website :0 [website](https://sites.google.com/view/websiteiniciobawer/in%C3%ADcio)")
  .setFooter(`Comando solicitado por: ${message.author.tag}`)
  .setTimestamp();
  
  message.channel.send(embed)

}