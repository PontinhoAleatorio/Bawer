const Discord = require("discord.js");

exports.run = (client, message, args) => {
    const embed = new Discord.MessageEmbed()
    .setColor('#08ddf5')
    .setDescription(`Help Bawer's ${message.author}`)
    .setImage('https://cdn.discordapp.com/attachments/826581424744169505/827570156409585734/My_Post_5.png')
    .setThumbnail('https://cdn.discordapp.com/avatars/805135276208422972/f5b4aa992ad6b1f5dc52ba39c670e27e.png?size=1024')
    .setTimestamp()
    .setFooter(` Comando feito pelo usuario: ${message.author.username} `)
    .addFields(
        {
            name: 'Todos os comandos no website',
            value: `[Meus comandos](https://sites.google.com/view/comandos-bawer/in%C3%ADcio)`,
            inline: true
        },
        {
            name: 'Me adicione!',
            value: `[Me adicione por aqui!](https://www.google.com/url?q=https%3A%2F%2Fdiscord.com%2Foauth2%2Fauthorize%3Fclient_id%3D805135276208422972%26scope%3Dbot%26permissions%3D8t&sa=D&sntz=1&usg=AFQjCNHDEtXQc_z1g8MHDO6x6CV2r-N2eQ) [O meu servidor!](https://discord.gg/583KNCh2Fk)`,
            inline: true
        },
    )
    message.channel.send(embed);
}