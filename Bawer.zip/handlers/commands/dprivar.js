exports.run = (client, message, args) => {
 if (!client.lockit) client.lockit = [];
 if (!message.member.hasPermission("MANAGE_CHANNELS")) return message.reply("❌**Error:** você não tem permissão "); message.channel.createOverwrite(message.guild.id, {
 VIEW_CHANNEL: null,
 ATTACH_FILES: false
 })
 message.channel.send(`Prontinho, **${message.author.username}** Agora todos do server podem ver este canal, para deixar somente para adms digite: .privar`);
 };