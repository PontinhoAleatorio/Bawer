const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://media.giphy.com/media/Oc8lIQHZsXqDu/giphy.gif',
  'https://media.giphy.com/media/HrB1MUATg24Ra/giphy.gif',
  'https://media.giphy.com/media/wZ2SI2e3t1gR2/giphy.gif',
  'https://media.giphy.com/media/felYMe70wGGCc1YtXE/giphy.gif',
  'https://media.giphy.com/media/JpPugwJRMH6rm/giphy.gif',
  'https://media.giphy.com/media/JQFZzvTP7XmPBmcSdH/giphy.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido paradar um hamster!');
}
/*
message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('Hamster')
        .setColor('#000000')
        .setDescription(`${message.author} acaba de dar um hamster para ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter(':3')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}