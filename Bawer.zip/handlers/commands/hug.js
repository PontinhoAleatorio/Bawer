const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
 'https://media.giphy.com/media/l2QDM9Jnim1YVILXa/giphy.gif','https://media.giphy.com/media/GMFUrC8E8aWoo/giphy.gif','https://media.giphy.com/media/143v0Z4767T15e/giphy.gif','https://media.giphy.com/media/pXQhWw2oHoPIs/giphy.gif','https://media.giphy.com/media/IRUb7GTCaPU8E/giphy.gif','https://media.giphy.com/media/QFPoctlgZ5s0E/giphy.gif','https://media.giphy.com/media/LScnoPBUqI7bMwQOdf/giphy.gif','https://media.giphy.com/media/bJQZwn5Er70Iw/giphy.gif','https://media.giphy.com/media/lrr9rHuoJOE0w/giphy.gif','https://media.giphy.com/media/wSY4wcrHnB0CA/giphy.gif','https://media.giphy.com/media/od5H3PmEG5EVq/giphy.gif','https://media.giphy.com/media/du8yT5dStTeMg/giphy.gif','https://media.giphy.com/media/fLv2F5rMY2YWk/giphy.gif','https://media.giphy.com/media/JLovyTOWK4cuc/giphy.gif','https://media.giphy.com/media/5eyhBKLvYhafu/giphy.gif','https://media.giphy.com/media/aD1fI3UUWC4/giphy.gif','https://media.giphy.com/media/PHZ7v9tfQu0o0/giphy.gif','https://media.giphy.com/media/GcJN2Dz5XMDeM/giphy.gif','https://media.giphy.com/media/1434tCcpb5B7EI/giphy.gif','https://media.giphy.com/media/HgG94OVFjDR4s/giphy.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para abraçar!');
}
/*
message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('❤️Abraço❤️')
        .setColor('#ff0000')
        .setDescription(`${message.author} acaba de abraçar ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('Abracinho web❤️!')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}