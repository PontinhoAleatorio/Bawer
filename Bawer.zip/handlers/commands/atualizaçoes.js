const Discord = require("discord.js");

exports.run = (client, message, args) => {
    const embed = new Discord.MessageEmbed()
    .setColor('#08ddf5')
    .setDescription(`Atualizações Bawer's ${message.author}`)
    .setThumbnail('https://cdn.discordapp.com/avatars/805135276208422972/f5b4aa992ad6b1f5dc52ba39c670e27e.png?size=1024')
    .setTimestamp()
    .setFooter(`Comando feito pelo usuario: ${message.author.username} `)
    .addFields(
        {
            name: 'Comandos novos',
            value: `.chamarparacomer, .darcomida .chamarparabeber`,
            inline: true
        },
        {
            name: 'Total de comandos',
            value: `102 comandos no total`,
            inline: true
        },
        {
            name: 'Quer ser o primeiro a usar novos comandos?',
            value: `Entre no meu [servidor e use meus novos comandos](https://discord.gg/ZxggBJrkAt) antes de todo mundo!`,
            inline: true
        },
    )
    message.channel.send(embed);
}