module.exports.run = async (client, message, args) => {
    var id = message.channel.id
    var channel = message.channel.guild.channels.cache.get(id)

    const member = message.member.user.id

    console.log(member)

    var oratoria = ['Oie!', 'Minha melhor amiga é a Bawer', '<:Bawer:842704129230766100> adicione a Bawer em seu servidor cara. Basta digitar `.adicionar` ^-^', '<:Gato_sad5:845681789061300244> Pelo visto eu não sei ler direito<:Gato_sad7:845681909727494215>', 'Sim, mas você ja tomou agua hoje?', 'Claro meu anjo', 'Bom dia', 'Boa noite', 'Boa tarde', 'So queria dormir, mais manda a braba', '<:Gato_sad4:845679549782163477>', '<:Gato_sad5:845681789061300244> Eu tenho sentimentos sabia?', '<:Gato_sad8:845681962642964556> legal legal']
     if(!args.slice(0).join(" ")) return message.channel.send("💁‍♂️ | Por favor mande uma pergunta para o Antares responder")
    

    var oratoriaRandon = Math.floor(Math.random() * oratoria.length)

    console.log(oratoriaRandon)
    try {
        await channel.createWebhook("Antares", {
            avatar: 'https://cdn.discordapp.com/avatars/821840911486812161/83ca1ac0dcf31bd91e7ae8204381fac9.png?size=1024'
        })
        .then(console.log('me derubaram aqui'))

        const webhooks = await channel.fetchWebhooks();
		const webhook = webhooks.first();

        await webhook.send(`${oratoria[oratoriaRandon]}`)
        webhook.delete()
    } catch (error) {
        console.log(error)
    }
}