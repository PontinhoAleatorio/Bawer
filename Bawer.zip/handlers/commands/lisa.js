const Discord = require('discord.js');
const DIG = require('discord-image-generation');

module.exports = {
    name: 'presentation',
    category: 'fun',
    run: async(client, message, args) => { // change the handler if not work
        let text = args.join(" ");
        if(!args.length) return message.channel.send(`💁‍♂️ Uso: lisa <seu texto>`)
        let image = await new DIG.LisaPresentation().getImage(text)
        let attach = new Discord.MessageAttachment(image, 'presentation.png');;
        message.channel.send(attach)
    }
}
