const { MessageEmbed } = require('discord.js');

module.exports = {
    name: "bans",
    category: "extra",
    run: async (client, message, args) => {

        message.guild.fetchBans().then(bans => {
            message.channel.send(`:man_tipping_hand: Os moderadores/adiministradores deste servidor ja baniu ${bans.size} membros `)
        })

    }
}