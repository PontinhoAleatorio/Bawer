const Discord = require("discord.js");

exports.run = (client, message, args) => {
    const embed = new Discord.MessageEmbed()
    .setColor('#08ddf5')
    .setDescription(`Brawer infor's ${message.author.username}`)
   .setThumbnail(`https://cdn.discordapp.com/avatars/805135276208422972/f5b4aa992ad6b1f5dc52ba39c670e27e.png?size=1024`)
    .setImage(`https://cdn.discordapp.com/attachments/808777821546741783/825825559455989829/My_Post_3.png`)
    .setTimestamp()
    .setFooter(`Comando feito pelo usuario: ${message.author.username} `)
    .addFields(
        {
            name: '<:Bawer:842704129230766100> | Bawer',
            value: `Hey ${message.author.username} Caso queira encontrar outras informações entre em [blog da Bawer](https://sites.google.com/view/blogbawer/bawers)`,

        },
        {
           name: '🔨 |Criador',
           value: `Nick atual do criador da Bawer: Hey Pontinho's#0312`
        },
        {
            name: '<:Bawer2:842707952477667338> | Infos',
            value: `Meu ping atual é de: 🏓\`${client.ws.ping}\`ms
            💁‍♂️${client.guilds.cache.size} servidores
            💁‍♂️ ${client.channels.cache.size} canais
            💁‍♂️${client.users.cache.size} usuários`,

        },
        {
            name: 'Website',
            value:`Hey ${message.author} você pode ver mais coisas em [website Bawer](https://sites.google.com/view/websiteiniciobawer/in%C3%ADcio)`,

        },
        
    )
    message.channel.send(embed);
}