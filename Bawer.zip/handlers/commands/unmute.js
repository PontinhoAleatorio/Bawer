module.exports = {
    name: "unmute",
    description: "Unmute a member from your server",

    async run (client, message, args) {
        if(!message.member.hasPermission("MANAGE_ROLES")) return message.channel.send("Você não tem permissão para executar este comando");

        let user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

        let role = message.guild.roles.cache.find(x => x.name === "Silenciado");

        if(user.roles.cache.has(role)) return message.channel.send("Este membro não está silenciado");

        user.roles.remove(role);

        message.channel.send(`<:unmute:825819478264119426> |${user} Foi desmutado`)
    }
}