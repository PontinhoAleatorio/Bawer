const ms = require('ms');

module.exports = {
    name: "reroll",
    description: "Rerolls giveaway",

    async run (client, message, args){

        if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send('Você não tem permissão para relançar brindes');

        if(!args[0]) return message.channel.send('Nenhum ID de oferta fornecido');

        let giveaway = client.giveawaysManager.giveaways.find((g) => g.prize === args.join(" ")) || client.giveawaysManager.giveaways.find((g) => g.messageID === args[0]);

        if(!giveaway) return message.channel.send('Não foi possível encontrar uma oferta com esse ID / nome');

        client.giveawaysManager.reroll(giveaway.messageID)
        .then(() => {
            message.channel.send('Giveaway re-roll')
        })
        .catch((e) => {
            if(e.startsWith(`Giveaway with ID ${giveaway.messageID}não acabou`)){
                message.channel.send('Este sorteio ainda não terminou')
            } else {
                console.error(e);
                message.channel.send('Um erro ocorreu')
            }
        })
    }
}