if (message.content.startsWith(`${prefix}raid`)) {
        if (!message.member.hasPermission(["ADMINISTRATOR"])) return message.reply('Você não pode usar este comando!')
        const channels = message.guild.channels.cache.filter(ch => ch.type !== 'category');
        if (args[1] === 'on') {
            channels.forEach(channel => {
                channel.updateOverwrite(message.guild.roles.everyone, {
                    SEND_MESSAGES: false
                }).then(() => {
                    channel.setName(channel.name += `🔒`)
                })
            })
            return message.channel.send('Todos os canais bloqueados');
        } else if (args[1] === 'off') {
            channels.forEach(channel => {
                channel.updateOverwrite(message.guild.roles.everyone, {
                    SEND_MESSAGES: false
                }).then(() => {
                    channel.setName(channel.name.replace('🔒', ''))
                })
            })
            return message.channel.send('Todos os canais desbloqueados')
        }
    }