const Discord = require('discord.js')

module.exports = {
name:"reportbug",
aliases:["bug"],
run: async (client, message, args) => {

let user = client.users.cache.get("839595775729860659")

const reporte = args.join(" ")
if(!reporte) return message.channel.send(`${message.author} você deve digitar o servidor`) 

const embed = new Discord.MessageEmbed()
.setTitle("Novo servidor reportado")
.addField("Autor Da Mensagem", `\`${message.author.tag}\`\n\`${message.author.id}\``)
.addField("Servidor Reportado", `${reporte}`)
.setFooter(`Reportado em ${message.guild.name}`)
.setColor("RANDOM")
user.send(embed)
}}