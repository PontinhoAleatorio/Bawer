const Discord = require("discord.js")
const db = require("quick.db")

module.exports.run = async (client, message, args) => {

let moedas = await db.fetch(`moedas_${message.author.id}`)
if(moedas === null) moedas = 0;


const cu = new Discord.MessageEmbed()
.setTitle(`Braws de ${message.author.username}`)
.setDescription(moedas)
.setColor("BLUE")
message.channel.send(cu)
  
}
module.exports.help = {
aliases: ["money", "braws"],
name: "bal"
}