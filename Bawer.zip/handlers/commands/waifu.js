const Discord = require('discord.js');

module.exports = {

    name: 'waifu',
    description: 'Mostra se sua waifu é boa ou não',
    author: 'Mennyf',


    run: async (client, message, args) => {

    let waifu = Math.round(Math.random() * 100)
        let pessoinha = message.mentions.users.first() || message.author;
        if(!pessoinha) return message.channel.send(`${message.author}, Mencione sua waifu!`)

        let frase
    if(waifu > 80) {
      waifu = ("é uma waifu quase perfeita, falta só um pó de pirimplimplim!");
    } else if(waifu>= 40) {
      waifu = ("é uma waifu boa, mas da para melhorar!"); 
    } else if(waifu>= 10){
      waifu = ("é uma waifu bem mediocre!")
    } else {
      waifu = ("é uma waifu horrível, troca agora!"); 
    }
    let embedin = new Discord.MessageEmbed()
    .setTitle('Waifinha!')
    .setDescription(`<a:sussydrip:850791148519948308>| ${pessoinha} ${waifu}`)
    .setColor('BLACK')

    message.channel.send(`${message.author}`, embedin)


}}
