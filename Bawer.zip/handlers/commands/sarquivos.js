exports.run = (client, message, args) => {
 if (!client.lockit) client.lockit = [];
 if (!message.member.hasPermission("MANAGE_CHANNELS")) return message.reply("❌**Error:** você não tem permissão "); message.channel.createOverwrite(message.guild.id, {
 CREATE_INVITATION: false,
 ATTACH_FILES: false
 })
 message.channel.send(`Prontinho, ${message.author} Agora somente adms podem mandar arquivos neste canal, para desbloquear basta fazer o comando: .parquivos`);
 };