module.exports.run = async (client, message, args) => {
    var id = message.channel.id
    var channel = message.channel.guild.channels.cache.get(id)

    const member = message.member.user.id

    console.log(member)

    var oratoria = ['Eu sou muito macho', 'Sim meu anjo', 'Eu jamais faria isso!', 'Não sua anta', 'La vem...', 'Não', 'Claro que não', 'Sim', 'Claro que sim', 'Talvez', 'Ja tentou dizer Bawer vai se foder? Se bão tenta ai kk...']
     if(!args.slice(0).join(" ")) return message.channel.send("💁‍♂️ | Por favor mande uma pergunta para o Soy Macho responder")
    

    var oratoriaRandon = Math.floor(Math.random() * oratoria.length)

    console.log(oratoriaRandon)
    try {
        await channel.createWebhook("Soy Macho", {
            avatar: 'https://cdn.discordapp.com/avatars/617140467213271040/6b773e0d0ff2d2b77397b404c77732ec.webp?size=4096'
        })
        .then(console.log('me derubaram aqui'))

        const webhooks = await channel.fetchWebhooks();
		const webhook = webhooks.first();

        await webhook.send(`${oratoria[oratoriaRandon]}`)
        webhook.delete()
    } catch (error) {
        console.log(error)
    }
}